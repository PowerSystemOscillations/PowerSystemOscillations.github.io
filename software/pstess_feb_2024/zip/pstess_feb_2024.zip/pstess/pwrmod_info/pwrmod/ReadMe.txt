D. Trudnowski.

psfv2p1 is a version of pstV2 developed by Trudnowsk (2015) that includes power injection modeling.  
It was developed under contract to Sandia in 2014/15 (see folder SandiaPO1540656).

Notes on modeling solar systems V3MTECHpstV2p1.docx = notes on the development.

PSTv2_pwrmod_Draft3.docx = report on using pstV2p1.  Folder "Examples" = examples in the report.

