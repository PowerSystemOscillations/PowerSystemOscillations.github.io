%#######################################
% This File runs a load flow and outputs the results in a UI
% This is the version compatible with 2014b and up
% Authors Christoph Lackner, Daniel Douglas
% 12/8/2017

%% ########### Generate Figure Portion ##############
position = get(0, 'Screensize');
position = position + [19, 100, -40,-210];

f = figure('Position',position);
f.ToolBar= 'none';
f.MenuBar = 'none';

position(1) = 0;
position(2) = 0;

l = uicontrol(f,'Style','text');
l.String = 'System: N/A';
l.Position = position + [20,-10,0,0];
l.FontSize = 20;
l.Tag = 'sys';

fname = uicontrol(f,'Style','text');
fname.String = '';
fname.Tag = 'fname';
fname.Visible = 'off';

m = uimenu(f,'Label','PST');
msystem = uimenu(m,'Label','load system','Callback',@(src,event)select_sys(f));
mac = uimenu(m,'Label','run AC powerflow','Callback',@(src,event)run_AC(f));
mdc = uimenu(m,'Label','run DC powerflow','Callback',@(src,event)run_DC(f));
mptdf = uimenu(m,'Label','compute PTDF','Callback',@(src,event)get_PTDF(f));
mlodf = uimenu(m,'Label','compute LODF','Callback',@(src,event)get_LODF(f));


position = position - [-50,-50,100,100];

tab_group = uitabgroup(f);
tab_group.Units = 'pixels';
tab_group.Position = position;


bus_tab = uitab(tab_group,'Title','Bus Summary');
line_tab = uitab(tab_group,'Title','Line Summary');
system_tab = uitab(tab_group,'Title','System Summary');
f.Name = 'PST Loadflow Visualization';

position(1) = 0;
position(2) = 0;

%% ######  Generate Table with Buses #######

col_name = {'Bus #','Voltage (pu)','Phase (deg)','P Load (pu)','Q Load (pu)','P gen (pu)','Q gen (pu)', 'Bus type (pu)'};
tbl_bus = uitable(bus_tab,'ColumnName',col_name,'Tag','tbl_bus');
tbl_bus.Position = position - [-20,-20,60,60];

%% ######  Generate Table with Lines #######

col_name = {'From Bus','To Bus','sending P (pu)','recieving P (pu)','sending Q (pu)','recieving Q (pu)','P loss (pu)','Q loss (pu)'};
tbl_line = uitable(line_tab,'ColumnName',col_name,'Tag','tbl_line');
tbl_line.Position = position - [-20,-20,60,60];

% ###### Table with system Summary ############

col_name = {'Describtion','value'};
tbl_system = uitable(system_tab,'ColumnName',col_name,'Tag','tbl_system');
tbl_system.Position = position - [-20,-20,60,60];

% ########## Update Table #################
function update(f,bus_sol,line,line_flw,runtime)
    
    chld = allchild(f);
    
     for k=1:length(chld)
        
       if  isa(chld(k),'matlab.ui.container.TabGroup')
           
           chld_tabgroup = allchild(chld(k));
           for j = 1:length(chld_tabgroup)
               
               if (isa(chld_tabgroup(j),'matlab.ui.container.Tab'))
                   
                   chld_tab = allchild(chld_tabgroup(j));
                   for i=1:length(chld_tab)
                      
                       if isa(chld_tab(i),'matlab.ui.control.Table')
                          if (strcmp(chld_tab(i).Tag,'tbl_system'))
                             tbl_system = chld_tab(i);
                          elseif (strcmp(chld_tab(i).Tag,'tbl_line'))
                              tbl_line = chld_tab(i);
                          elseif (strcmp(chld_tab(i).Tag,'tbl_bus'))
                              tbl_bus = chld_tab(i);
                          end
                       end
                   end
               end
           end
       end
     end
    
     
    data = {};
    nbus = size(bus_sol,1);
    
    for k = 1:nbus
        data{k,1} = sprintf('%d',bus_sol(k,1));
        data{k,2} = sprintf('%1.4f',bus_sol(k,2));
        data{k,3} = sprintf('%3.2f',bus_sol(k,3));
        data{k,4} = sprintf('%3.2f',bus_sol(k,6));
        data{k,5} = sprintf('%3.2f',bus_sol(k,7));
        data{k,6} = sprintf('%3.2f',bus_sol(k,4));
        data{k,7} = sprintf('%3.2f',bus_sol(k,5));
        
        switch (bus_sol(k,10))
            case 1
                data{k,8} = 'Swing Bus';
            case 2
                data{k,8} = 'Gen Bus';
            case 3
                data{k,8} = 'Load Bus';
            otherwise
                data{k,8} = 'N/A';
        end
        
    end

    tbl_bus.Data = data;
    
    data = {};
    nline = size(line_flw,1)/2;
    
    for k = 1:nline
        data{k,1} = sprintf('%d',line(k,1));
        data{k,2} = sprintf('%d',line(k,2));
        
        data{k,3} = sprintf('%3.2f',line_flw(k,4));
        data{k,4} = sprintf('%3.2f',-line_flw(k+nline,4));
        data{k,5} = sprintf('%3.2f',line_flw(k,5));
        data{k,6} = sprintf('%3.2f',-line_flw(k+nline,5));
        Ploss = line_flw(k,4) + line_flw(k+nline,4);
        Qloss = line_flw(k,5) + line_flw(k+nline,5);
        data{k,7} = sprintf('%3.2f',Ploss);
        data{k,8} = sprintf('%3.2f',Qloss);
    end
    
    tbl_line.Data = data;
    
    Pgen = sum(bus_sol(:,4));
    Qgen = sum(bus_sol(:,5));
    Pload = sum(bus_sol(:,6));
    Qload = sum(bus_sol(:,7));
    Ploss = Pgen - Pload;
    Qloss = Qgen - Qload;
    data = {'Total P generation',sprintf('%3.2f',Pgen); 'Total Q generation',sprintf('%3.2f',Qgen); 'Total P Load',sprintf('%3.2f',Pload);...
        'Total Q Load',sprintf('%3.2f',Qload); 'Total P Losses',sprintf('%3.2f',Ploss); 'Total Q Losses',sprintf('%3.2f',Qloss);'Run Time (ms)',...
        sprintf('%3.2f',runtime.*1000)};

    tbl_system.Data = data;
end

% ######### Run AC Powerflow #########
function run_AC(f)
    
    
    fname = '';
    
    chld = allchild(f);
    
    for k=1:length(chld)
        if (strcmp(chld(k).Tag,'fname'))
            fname = chld(k).String;
        end
    end

    
    if (exist(fname,'file')==2)
        
        run(fname(1:end-2));
        
        tol = 1e-8; 
        iter_max = 30;
        acc = 1.0;
        tic;
        [bus_sol,line,line_flw] = loadflow(bus,line,tol,iter_max,acc,'n',2);
        runtime = toc;
        
        clear_table(f);
        update(f,bus_sol,line,line_flw,runtime);
    else
        clear_table(f);
    end
   
end

% ######### Run DC Powerflow #########
function run_DC(f)
    
    
    fname = '';
    
    chld = allchild(f);
    
    for k=1:length(chld)
        if (strcmp(chld(k).Tag,'fname'))
            fname = chld(k).String;    
        end
    end
    
    if (exist(fname,'file')==2)
        
        line = [];
        bus = [];
        
        run(fname(1:end-2));
        
        tic;
        [bus_sol,~,line_flw,~] = dcloadflow(bus,line,'n');
        runtime = toc;
        
        clear_table(f);
        update(f,bus_sol,line,line_flw,runtime);
    else
        clear_table(f);
    end
   
end

% ######### Select System ###############
function select_sys(f)
    clear_table(f);
    [FileName,PathName,~] = uigetfile('*.m','Select System data File');
    
    chld = allchild(f);
    
    for k=1:length(chld)
        if (strcmp(chld(k).Tag,'fname'))
            chld(k).String = [PathName FileName];
        elseif (strcmp(chld(k).Tag,'sys'))
            chld(k).String = ['System: ' FileName];
        end
    end
    
end

% ######## Clear Tables ##############
function clear_table(f)
    chld = allchild(f);
    
    for k=1:length(chld)
        
       if  isa(chld(k),'matlab.ui.container.TabGroup')
           
           chld_tabgroup = allchild(chld(k));
           for j = 1:length(chld_tabgroup)
               
               if (isa(chld_tabgroup(j),'matlab.ui.container.Tab'))
                   
                   chld_tab = allchild(chld_tabgroup(j));
                   for i=1:length(chld_tab)
                      
                       if isa(chld_tab(i),'matlab.ui.control.Table')
                          chld_tab(i).Data = {}; 
                       end
                   end
               end
           end
       end
    end
end

% ########### Compute PTDF #############
function get_PTDF(f)
    fname = '';
    
    chld = allchild(f);
    
    for k=1:length(chld)
        if (strcmp(chld(k).Tag,'fname'))
            fname = chld(k).String;
        end
    end
    
    if (exist(fname,'file')==2)
        
        line = [];
        bus = [];
        
        run(fname(1:end-2));
        
        n_line = size(line,1);
        n_bus = size(bus,1);
        
        %Open PTDF Bus and Line selection
        str = {};
        for k = 1:n_line
            str(k) = {['Line ' sprintf('%d',line(k,1)) '-' sprintf('%d',line(k,2))]};
        end
        [selected_line,line_ok] = listdlg('PromptString','Select a Line:',...
                'SelectionMode','single','OKString','Next',...
                'ListString',str);
            
       % 2 Bus Selection
       str = {};
        for k = 1:n_bus
            str(k) = {['Bus ' sprintf('%d',bus(k,1))]};
        end
        [idx,gen_ok] = listdlg('PromptString','Select a Generator Bus:',...
                'SelectionMode','single','OKString','Next',...
                'ListString',str);
            
        selected_gen = bus(idx,1);
        [idx,load_ok] = listdlg('PromptString','Select a Load Bus:',...
                'SelectionMode','single','OKString','Compute',...
                'ListString',str);
        selected_load = bus(idx,1);    
       % Display Result
       if (load_ok && gen_ok && line_ok)
           [ptdf] = PTDF(bus,line,[selected_gen,selected_load],line(selected_line,1:2));
           
           h = msgbox(['PTDF of Line ' sprintf('%d%',line(selected_line,1))....
               '-' sprintf('%d%',line(selected_line,2)) ' from Bus ' sprintf('%d',selected_gen)...
               ' to Bus ' sprintf('%d',selected_load) ' is: ' sprintf('%1.5f',ptdf)]);
           h.Name = 'PTDF Computed';
       end
    end
end

% ########### Compute LODFs #############
function get_LODF(f)
    fname = '';
    
    chld = allchild(f);
    
    for k=1:length(chld)
        if (strcmp(chld(k).Tag,'fname'))
            fname = chld(k).String;
        end
    end
    
    if (exist(fname,'file')==2)
        
        line = [];
        bus = [];
        
        run(fname(1:end-2));
        
        n_line = size(line,1);
        
        %Open LODF Line selection
        str = {};
        for k = 1:n_line
            str(k) = {['Line ' sprintf('%d',line(k,1)) '-' sprintf('%d',line(k,2))]};
        end
        [selected_trip,trip_ok] = listdlg('PromptString','Select a Line to trip:',...
                'SelectionMode','single','OKString','Next',...
                'ListString',str);
            
       % Select 2nd Line
       if (trip_ok)
        [selected_line,line_ok] = listdlg('PromptString','Select an affected Line:',...
                'SelectionMode','single','OKString','Next',...
                'ListString',str);
       
            % Display Result
            if (line_ok)
                
                lodf = LODF(bus,line,line(selected_trip,1:2),line(selected_line,1:2));
                h = msgbox(['LODF of Line ' sprintf('%d%',line(selected_trip,1))....
                    '-' sprintf('%d%',line(selected_trip,2)) ' on Line ' sprintf('%d%',line(selected_line,1))....
                    '-' sprintf('%d%',line(selected_line,2)) ' is: ' sprintf('%1.5f',lodf)]);
                h.Name = 'LODF Computed';
            end
       end
    end
end