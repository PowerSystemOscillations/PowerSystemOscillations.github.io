%% Calculate DC Loadflow
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author:    Daniel Douglas, Christoph Lackner                           %
% Date:      2017/12/1                                                   %
%                                                                        %
% Purpose:   This function takes the bus and line data of a power system %
%            and performs a "DC" linear, noniterative power flow         %
%                                                                        %
% Use:       [bus_sol,line_sol,line_flw,B] = dcloadflow(bus,line,flag)   %
%                                                                        %
% Inputs:   -bus : (matrix) : The bus data for the system (format see    %
%            bottom line)                                                %
%           -line : (matrix) : The line data for the matrix.             %
%           -flag : ('y'/'n') : indicates if the results are printed to  %
%            the cmd line (default 'n')                                  %
%                                                                        %
% Outputs:  -bus_sol : (matrix) : system loadflow bus data               %
%           -line_sol : (matrix) : the system line data (same as input)  %
%           -line_flw : (matrix) : system solved line flow data          %
%           -B : (matrix) : Susceptance matrix                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [bus_sol, line_sol, line_flw, B] = dcloadflow(bus,line,flag)

[nline, nlc] = size(line);    % number of lines and no of line cols
[nbus, ncol] = size(bus);     % number of buses and number of col
line_sol = line;
bus_sol = bus;

if isempty(flag)
    flag = 'n';
end

% Get bus numbers
bus_N = bus(:,1);

% Construct B matrix from branch data ignoring resistance and line
% charging
%
B = zeros(nbus);

for i = 1:nline
    % Assign susceptance value using from and to bus as lookup table index
    %
    B( line(i,1)==bus_N, line(i,2)==bus_N) = ...
    -1/line(i,4) + B(line(i,1), line(i,2) );
end

% Reflect B matrix across diagonal to produce symmetric B-matrix
B = B + B';
B = B - diag(sum(B));

% Index of reference as logical array
ref_ix = bus(:,10) == 1;

% Remove the line/column of the reference bus(es) to create reduced matrix
%
B_red = B;
B_red(ref_ix,:)=[];
B_red(:,ref_ix)=[];

% Power gen/load reduced vector
%
P(:,1) = bus(:,4) - bus(:,6);
P(ref_ix) = [];

% Solve power angles reduced vector
Theta_red = B_red \ P;

% Replace removed row in angle vector
%
Theta = zeros(nbus,1);
Theta(~ref_ix) = Theta_red;

% Solve power flow vector
P = B * Theta;

% Compute line flows
%
Pflow = zeros(nline,1);

for i = 1:nline
    Pflow(i,1) = -B( line(i,1)==bus_N, line(i,2)==bus_N ) * ...
        ( Theta(line(i,1)==bus_N) - Theta(line(i,2)==bus_N) );
end

% Report angles in degrees
Theta = Theta .* 180/pi;

% Report output data

% Reorder Line Flow and Bus solution
bus_sol(:,2) = 1.0;
bus_sol(:,3) = Theta;
bus_sol(:,5) = 0;
bus_sol(:,7) = 0;
bus_sol(ref_ix,4) = P(ref_ix);

zero = zeros(nline,1);
line_flw = [(1:nline).',line(:,1:2), Pflow, zero];
        
line_flw = [line_flw;line_flw];
line_flw((nline+1):end,2) = line_flw(1:nline,3);
line_flw((nline+1):end,3) = line_flw(1:nline,2);
line_flw((nline+1):end,4) = -line_flw(1:nline,4);

% Display Output if desired

% display results
if flag == 'y'
   clc
   disp('                          DC LOAD-FLOW STUDY')
   disp('                    REPORT OF POWER FLOW CALCULATIONS ')
   disp(' ')
   disp(date)
   fprintf('SWING BUS                  : BUS %g \n', bus(ref_ix,1))
      disp('                                      GENERATION             LOAD')
      disp('       BUS     VOLTS     ANGLE      REAL  REACTIVE      REAL  REACTIVE ')
      disp(bus_sol(:,1:7))
      
      disp('                      LINE FLOWS                     ')
      disp('      LINE  FROM BUS    TO BUS      REAL  REACTIVE   ')
      disp(line_flw(1:nline,:))
      disp(line_flw((1+nline):end,:))
end

end % END function

%% Loadflow Data Format Reference
    % BUS Data Format
    %%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   Bus Number                          #
        %   2   Voltage Magnitude                   V_mag   (p.u.)
        %   3   Voltage Angle                       delta   (degrees)
        %   4   Real Power GENERATED                P_gen   (p.u.)
        %   5   Reactive Power GENERATED            Q_gen   (p.u.)
        %   6   Real Power CONSUMED                 P_load  (p.u.)
        %   7   Reactive Power CONSUMED             Q_load  (p.u.)
        %   8   Shunt Conductance                   G       (p.u.) G = 1/R
        %   9   Shunt Susceptance                   B       (p.u.) B = 1/X
        %  10   Bus Type
            % = 1 for swing bus
            % = 2 for generator bus (PV bus)
            % = 3 for load bus (PQ bus)
        %  11   Maximum Reactive Power Generated    Q_gen_max (p.u.)
        %  12   Minimum Reactive Power Generated    Q_gen_min (p.u.)
        
    % LINE Data Format
    %%%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   From Bus                #
        %   2   To Bus                  #
        %   3   Line Resistance         R (p.u.)
        %   4   Line Reactance          X (p.u.) 
        %   5   Line Charging           B (p.u.)
        %   6   Tap Ratio               #
        %   7   Phase Shifter Angle     (degrees)
        
     % bus_sol Data Format
    %%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   Bus Number                          #
        %   2   Voltage Magnitude                   V_mag   (p.u.)
        %   3   Voltage Angle                       delta   (degrees)
        %   4   Real Power GENERATED                P_gen   (p.u.)
        %   5   Reactive Power GENERATED            Q_gen   (p.u.)
        %   6   Real Power CONSUMED                 P_load  (p.u.)
        %   7   Reactive Power CONSUMED             Q_load  (p.u.)
        %   8   Shunt Conductance                   G       (p.u.) G = 1/R
        %   9   Shunt Susceptance                   B       (p.u.) B = 1/X
        %  10   Bus Type
            % = 1 for swing bus
            % = 2 for generator bus (PV bus)
            % = 3 for load bus (PQ bus)
        %  11   Maximum Reactive Power Generated    Q_gen_max (p.u.)
        %  12   Minimum Reactive Power Generated    Q_gen_min (p.u.)
        
    % line_sol Data Format
    %%%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   From Bus                #
        %   2   To Bus                  #
        %   3   Line Resistance         R (p.u.)
        %   4   Line Reactance          X (p.u.) 
        %   5   Line Charging           B (p.u.)
        %   6   Tap Ratio               #
        %   7   Phase Shifter Angle     (degrees)  
        
    % line_flow Data Format
    %%%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   Line Number             #
        %   2   From Bus                #
        %   3   To Bus                  #
        %   4   Active Line flow        P (p.u.)
        %   5   Reactive Line flow      Q (p.u.) 
        