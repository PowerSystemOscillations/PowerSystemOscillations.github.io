%% Calculate PTDF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author:    Christoph Lackner, Daniel Douglas                           %
% Date:      2017/12/7                                                   %
%                                                                        %
% Purpose:   This function computes the PTDFs for a given                %
%            set of Lines and Buses                                      %
%                                                                        %
% Use:       [ptdf_val] = PTDF(bus, line, bus_spec, line_spec)           %
%                                                                        %
% Inputs:   -bus : (matrix) : The bus data for the system (format see    %
%                             bottom line)                               %
%           -line : (matrix) : The line data for the matrix.             %
%           -bus_spec : (vector) : the bus number of 2 injection buses   %
%           -line_spec : (vector) : The term buses of the line observed  % 
%                                                                        %
% Outputs: - ptdf_val : (float) : power transfer distribution factor     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ptdf_val] = PTDF(bus,line,bus_spec,line_spec)

    
line_spec = (line(:,1)== line_spec(1) & line(:,2)== line_spec(2))...
    | (line(:,2)== line_spec(1) & line(:,1)== line_spec(2));

line_spec = find(line_spec);
line_spec = line_spec(1);

[ncol,nline] = size(bus_spec);
if (nline > ncol)
    bus_spec = bus_spec.';
    [ncol,nline] = size(bus_spec);
end
if (ncol ~= 2)
    error('Only specifiy two buses');
end

[nline, nlc] = size(line);    % number of lines and no of line cols
[nbus, ncol] = size(bus);     % number of buses and number of col


% Get bus numbers
bus_N = bus(:,1);

% Construct B matrix from branch data ignoring resistance and line
% charging
%
B = zeros(nbus);

for i = 1:nline
    % Assign susceptance ptdf_value using from and to bus as lookup table index
    %
    B( line(i,1)==bus_N, line(i,2)==bus_N) = ...
    -1/line(i,4) + B(line(i,1), line(i,2) );
end

% Reflect B matrix across diagonal to produce symmetric B-matrix
B = B + B';
B = B - diag(sum(B));

% Index of reference as logical array
ref_ix = 1;

% Remove the line/column of the reference bus(es) to create reduced matrix
%
B_red = B;
B_red(ref_ix,:)=[];
B_red(:,ref_ix)=[];

% create X matrix
X_red = inv(B_red);
X = zeros(nbus);

X(2:end,2:end) = X_red;

% compute PTDF
n = bus_N ==line(line_spec,1);
m = bus_N==line(line_spec,2);
i = bus_spec(1);
j = bus_spec(2);
           
ptdf_val = 1./(line(line_spec,4)).*((X(n,i)-X(n,j))-(X(m,i)-X(m,j)));

end % END function

%% Loadflow Data Format Reference
    % BUS Data Format
    %%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   Bus Number                          #
        %   2   Voltage Magnitude                   V_mag   (p.u.)
        %   3   Voltage Angle                       delta   (degrees)
        %   4   Real Power GENERATED                P_gen   (p.u.)
        %   5   Reactive Power GENERATED            Q_gen   (p.u.)
        %   6   Real Power CONSUMED                 P_load  (p.u.)
        %   7   Reactive Power CONSUMED             Q_load  (p.u.)
        %   8   Shunt Conductance                   G       (p.u.) G = 1/R
        %   9   Shunt Susceptance                   B       (p.u.) B = 1/X
        %  10   Bus Type
            % = 1 for swing bus
            % = 2 for generator bus (PV bus)
            % = 3 for load bus (PQ bus)
        %  11   Maximum Reactive Power Generated    Q_gen_max (p.u.)
        %  12   Minimum Reactive Power Generated    Q_gen_min (p.u.)
        
    % LINE Data Format
    %%%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   From Bus                #
        %   2   To Bus                  #
        %   3   Line Resistance         R (p.u.)
        %   4   Line Reactance          X (p.u.) 
        %   5   Line Charging           B (p.u.)
        %   6   Tap Ratio               #
        %   7   Phase Shifter Angle     (degrees)
        