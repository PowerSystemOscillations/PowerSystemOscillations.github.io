
%% Calculate LODF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author:    Christoph Lackner, Daniel Douglas                           %
% Date:      2017/12/7                                                   %
%                                                                        %
% Purpose:   This function computes the LODFs for a given                %
%            set of lines                                                %
%                                                                        %
% Use:       lodf_val = LODF(bus, line, trip_spec, line_spec)            %
%                                                                        %
% Inputs:   -bus : (matrix) : The bus data for the system (format see    %
%            bottom line)                                                %
%           -line : (matrix) : The line data for the matrix.             %
%           -trip_spec : (vector) : The term buses of the tripped line   %
%           -line_spec : (vector) : The term buses of the line observed  %
%                                                                        %
% Outputs:  -lodf_val : (float) : The line outage distribution factor    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lodf_val] = LODF(bus,line,trip_spec,line_spec)

     
    ptdf_1 = PTDF(bus,line,line_spec,line_spec);
    ptdf_2 = PTDF(bus,line,trip_spec,line_spec);

    lodf_val = 1/(1-ptdf_1).*ptdf_2;

end % END function

%% Loadflow Data Format Reference
    % BUS Data Format
    %%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   Bus Number                          #
        %   2   Voltage Magnitude                   V_mag   (p.u.)
        %   3   Voltage Angle                       delta   (degrees)
        %   4   Real Power GENERATED                P_gen   (p.u.)
        %   5   Reactive Power GENERATED            Q_gen   (p.u.)
        %   6   Real Power CONSUMED                 P_load  (p.u.)
        %   7   Reactive Power CONSUMED             Q_load  (p.u.)
        %   8   Shunt Conductance                   G       (p.u.) G = 1/R
        %   9   Shunt Susceptance                   B       (p.u.) B = 1/X
        %  10   Bus Type
            % = 1 for swing bus
            % = 2 for generator bus (PV bus)
            % = 3 for load bus (PQ bus)
        %  11   Maximum Reactive Power Generated    Q_gen_max (p.u.)
        %  12   Minimum Reactive Power Generated    Q_gen_min (p.u.)
        
    % LINE Data Format
    %%%%%%%%%%%%%%%%%%%%
        %Column Variable
        %------------------------------------------------------------------
        %   1   From Bus                #
        %   2   To Bus                  #
        %   3   Line Resistance         R (p.u.)
        %   4   Line Reactance          X (p.u.) 
        %   5   Line Charging           B (p.u.)
        %   6   Tap Ratio               #
        %   7   Phase Shifter Angle     (degrees)
        
    